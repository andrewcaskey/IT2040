// task = to print numbers 1-100
// scope = if multiple of 3 , print Fizz
// scope = if multiple of of 5, print Buzz
// socpe = if multiple of 3 and 5, print FizzBuzz


for (var i = 1; i < 101; i++) {
    if (i % 15 == 0) console.log("FizzBuzz");
    else if (i % 3 == 0) console.log("Fizz");
    else if (i % 5 == 0) console.log("Buzz");
    else console.log(i);
}
